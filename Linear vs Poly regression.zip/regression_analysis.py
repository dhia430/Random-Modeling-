import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error, mean_absolute_error
import pandas as pd

# ─────────────────────────────────────────────
# Data extracted from the table (zeros = missing → excluded)
# Columns read left-to-right: (y,x), (y,x), (y,x)
# ─────────────────────────────────────────────
RAW_Y = [95, 80,  0,  0, 79, 77,
         72, 66, 98, 90,  0, 95,
         35, 50, 72, 55, 75, 66]

RAW_X = [96, 77,  0,  0, 78, 64,
         89, 47, 90, 93, 18, 86,
          0, 30, 59, 77, 74, 67]

# Keep only pairs where BOTH x and y are non-zero
CLEAN_PAIRS = [(x, y) for x, y in zip(RAW_X, RAW_Y) if x != 0 and y != 0]
X_DATA = np.array([p[0] for p in CLEAN_PAIRS], dtype=float)
Y_DATA = np.array([p[1] for p in CLEAN_PAIRS], dtype=float)


# ══════════════════════════════════════════════
# PART 1 – LINEAR REGRESSION
# ══════════════════════════════════════════════

def linear_regression(x, y):
    model = LinearRegression()
    model.fit(x.reshape(-1, 1), y)
    b0 = model.intercept_
    b1 = model.coef_[0]
    return model, b0, b1


def plot_linear(x, y, model, b0, b1):
    y_pred = model.predict(x.reshape(-1, 1))
    x_line = np.linspace(x.min(), x.max(), 200)
    y_line = model.predict(x_line.reshape(-1, 1))

    plt.figure(figsize=(9, 6))
    plt.scatter(x, y, color='steelblue', s=70, zorder=3, label='Observed data')
    plt.plot(x_line, y_line, color='crimson', linewidth=2,
             label=f'Linear fit:  ŷ = {b0:.3f} + {b1:.3f}·x')
    plt.xlabel('x', fontsize=13)
    plt.ylabel('y', fontsize=13)
    plt.title('Linear Regression', fontsize=15, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('linear_regression.png', dpi=150)
    plt.show()
    print("  → Saved: linear_regression.png")


def error_stats(y_true, y_pred, label=''):
    errors = y_true - y_pred
    mean_err  = np.mean(errors)
    var_err   = np.var(errors, ddof=0)   # population variance
    mae       = mean_absolute_error(y_true, y_pred)
    rmse      = np.sqrt(mean_squared_error(y_true, y_pred))
    r2        = 1 - np.sum(errors**2) / np.sum((y_true - y_true.mean())**2)

    print(f"\n  {label} Error Analysis")
    print(f"  {'─'*40}")
    print(f"  Mean of errors          : {mean_err:>10.4f}")
    print(f"  Variance of errors      : {var_err:>10.4f}")
    print(f"  MAE                     : {mae:>10.4f}")
    print(f"  RMSE                    : {rmse:>10.4f}")
    print(f"  R²                      : {r2:>10.4f}")
    return mean_err, var_err


# ══════════════════════════════════════════════
# PART 2 – POLYNOMIAL REGRESSION
# ══════════════════════════════════════════════

def polynomial_regression(x, y, degree=2):
    poly = PolynomialFeatures(degree=degree, include_bias=True)
    x_poly = poly.fit_transform(x.reshape(-1, 1))
    model = LinearRegression(fit_intercept=False)  # bias already in poly features
    model.fit(x_poly, y)
    return model, poly


def print_poly_equation(model, degree):
    coeffs = model.coef_
    terms = [f"{coeffs[0]:.4f}"]
    for i in range(1, degree + 1):
        sign = '+' if coeffs[i] >= 0 else '-'
        terms.append(f"{sign} {abs(coeffs[i]):.4f}·x^{i}")
    print(f"  ŷ = {' '.join(terms)}")


def plot_polynomial(x, y, model, poly, degree):
    x_line = np.linspace(x.min(), x.max(), 300).reshape(-1, 1)
    y_line = model.predict(poly.transform(x_line))

    plt.figure(figsize=(9, 6))
    plt.scatter(x, y, color='steelblue', s=70, zorder=3, label='Observed data')
    plt.plot(x_line, y_line, color='darkorange', linewidth=2,
             label=f'Polynomial fit (degree {degree})')
    plt.xlabel('x', fontsize=13)
    plt.ylabel('y', fontsize=13)
    plt.title(f'Polynomial Regression  (degree {degree})', fontsize=15, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f'polynomial_regression_deg{degree}.png', dpi=150)
    plt.show()
    print(f"  → Saved: polynomial_regression_deg{degree}.png")


def plot_comparison(x, y, lin_model, poly_model, poly_feat, degree):
    x_line = np.linspace(x.min(), x.max(), 300).reshape(-1, 1)
    y_lin  = lin_model.predict(x_line)
    y_poly = poly_model.predict(poly_feat.transform(x_line))

    plt.figure(figsize=(10, 6))
    plt.scatter(x, y, color='steelblue', s=70, zorder=3, label='Observed data')
    plt.plot(x_line, y_lin,  color='crimson',    linewidth=2, linestyle='--', label='Linear fit')
    plt.plot(x_line, y_poly, color='darkorange',  linewidth=2, label=f'Polynomial fit (deg {degree})')
    plt.xlabel('x', fontsize=13)
    plt.ylabel('y', fontsize=13)
    plt.title('Comparison: Linear vs Polynomial Regression', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('comparison.png', dpi=150)
    plt.show()
    print("  → Saved: comparison.png")


# ══════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════

def main():
    global X_DATA, Y_DATA

    # ── Data input ──────────────────────────────
    print("\n" + "="*55)
    print("  DATA")
    print("="*55)
    choice = input("  Use table data? (yes / no): ").strip().lower()

    if choice == 'no':
        n = int(input("  Number of data points: "))
        xs, ys = [], []
        for i in range(n):
            xs.append(float(input(f"    x[{i+1}] = ")))
            ys.append(float(input(f"    y[{i+1}] = ")))
        X_DATA = np.array(xs)
        Y_DATA = np.array(ys)

    df = pd.DataFrame({'x': X_DATA, 'y': Y_DATA})
    print(f"\n  {len(df)} valid pairs loaded:\n")
    print(df.to_string(index=False))

    # ── Part 1 : Linear regression ──────────────
    print("\n" + "="*55)
    print("  PART 1 – LINEAR REGRESSION")
    print("="*55)

    lin_model, b0, b1 = linear_regression(X_DATA, Y_DATA)
    print(f"\n  Equation : ŷ = {b0:.4f} + {b1:.4f}·x")
    print(f"  β₀ (intercept) = {b0:.4f}")
    print(f"  β₁ (slope)     = {b1:.4f}")

    plot_linear(X_DATA, Y_DATA, lin_model, b0, b1)

    y_pred_lin = lin_model.predict(X_DATA.reshape(-1, 1))
    me_lin, var_lin = error_stats(Y_DATA, y_pred_lin, label='Linear')

    # ── Part 2 : Polynomial regression ──────────
    print("\n" + "="*55)
    print("  PART 2 – POLYNOMIAL REGRESSION")
    print("="*55)

    deg_input = input("\n  Polynomial degree (press Enter for 2): ").strip()
    degree = int(deg_input) if deg_input else 2

    poly_model, poly_feat = polynomial_regression(X_DATA, Y_DATA, degree=degree)
    print(f"\n  Equation:")
    print_poly_equation(poly_model, degree)

    plot_polynomial(X_DATA, Y_DATA, poly_model, poly_feat, degree)

    y_pred_poly = poly_model.predict(poly_feat.transform(X_DATA.reshape(-1, 1)))
    me_poly, var_poly = error_stats(Y_DATA, y_pred_poly, label=f'Polynomial (deg {degree})')

    # ── Comparison plot ──────────────────────────
    plot_comparison(X_DATA, Y_DATA, lin_model, poly_model, poly_feat, degree)

    # ── Summary ─────────────────────────────────
    print("\n" + "="*55)
    print("  SUMMARY")
    print("="*55)
    print(f"  Linear        →  Mean error = {me_lin:.4f},  Variance = {var_lin:.4f}")
    print(f"  Polynomial d={degree} →  Mean error = {me_poly:.4f},  Variance = {var_poly:.4f}")
    print("\n  Done. All plots saved.\n")


if __name__ == "__main__":
    main()
